//:# Welcome to my Playground


//: `Biscoito` is your friend and he is hungry, so let`s help our friend out. Feed him with the most delicious food ever.


//:How to play?
//:In this game you are `Biscoito`. You play with him by moving you finger around the screen.
//:Your goal is to eat the food avoiding the trash bags until you make 300 points.



//: So you already played for a while, now go and change de variable bellow to the value of: true
//:and se something interesting...
private var turnAIOnline = true


//: WOOOW!!! it plays it self now 'Biscoito' can catch food by him self, thats amazing, now he is more independependent.
//: by now you probaly have figured it out our friend is a metaphor for a machine that can do things but only if handled by us humans, computer automation makes much more possible lets all work to make every IOT device of ours smarter

//:credits:

//: music from youtube free aduio libray: "coupe" and "bite" .

//:food images that fall in the game were created by Freepik


import PlaygroundSupport
import SpriteKit
import GameplayKit

// Load the SKScene from 'GameScene.sks'
let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 375, height: 667))

if let scene = GameScene(fileNamed: "GameScene") {
    // Set the scale mode to scale to fit the window
    scene.scaleMode = .aspectFill
    if turnAIOnline{
    scene.activateAI()
    }
    // Present the scene
    sceneView.presentScene(scene)
    print(sceneView.frame.size.width)
}

PlaygroundSupport.PlaygroundPage.current.liveView = sceneView
