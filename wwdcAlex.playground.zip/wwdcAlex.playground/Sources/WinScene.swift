//
//  WinScene.swift
//  1.0_WWDC2018
//
//  Created by alexandre philippi on 26/03/18.
//  Copyright © 2018 Alexandre Philippi. All rights reserved.
//

import SpriteKit
import GameplayKit

public class WinScene: SKScene {
    
    private var winLabel: SKLabelNode!
    private var winBackground: SKSpriteNode!
    
    public override func didMove(to view: SKView) {
        self.backgroundColor = .blue
        
       winBackground = SKSpriteNode(imageNamed: "youWon.png")
        winBackground.position = CGPoint(x: self.frame.size.width/2, y: self.frame.size.height/2)
        winBackground.scale(to: self.frame.size)
        
        addChild(winBackground)
        
        
        winLabel = SKLabelNode(text: "YOU WON!!!!!!!!!!!!")
        self.anchorPoint = CGPoint.zero
        winLabel.position = CGPoint(x: self.frame.size.width/2 , y: self.frame.size.width/2)
        winLabel.fontSize = 100
        winLabel.fontColor = .white
        self.addChild(winLabel)
    }
    
}
