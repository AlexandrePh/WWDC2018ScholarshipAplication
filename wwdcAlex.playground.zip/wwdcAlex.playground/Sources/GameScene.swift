import PlaygroundSupport
import SpriteKit
import GameplayKit



//MARK: begin class
public class  GameScene: SKScene, SKPhysicsContactDelegate {
    
    private var player:SKSpriteNode!
    private var scoreLabel:SKLabelNode!
    private var backGround:SKSpriteNode!
    
    private var animation1:SKTexture!
    private var animation2:SKTexture!
    private var arrayAnimation: [SKTexture] = []
    
    private var velocity:Double = 0
    public var AI = false
    
    private var score:Int = 0 {
        didSet {
            scoreLabel.text = "Score: \(score)"
            velocity = Double(score)/50
        }
    }
    
    private var gameTimer:Timer!
    private var AIturn:Timer!
    private var level = 1.2
    private var possibleItem = ["macarrao.png", "pizza.png", "burguer.png","sandwich.png","taco.png","hotdog.png","guacamole.png","trash.png"]
    
    //MARK: BitMasks
    private let trashCategory:UInt32 = 3
    private let foodCategory:UInt32 = 2
    private let playerCategory:UInt32 = 1
    
    //MARK: AI properties
    
    
    private var GBackground:SKSpriteNode!
    private var arrayBoladao : [SKSpriteNode] = []
    
    
    override public func didMove(to view: SKView) {
        
        self.physicsWorld.contactDelegate = self
        
        self.anchorPoint = CGPoint.zero
        physicsWorld.gravity = CGVector(dx: 0, dy: 0)
        
        GBackground = SKSpriteNode(imageNamed: "backG.png")
        GBackground.position = CGPoint(x: self.frame.size.width/2, y: self.frame.size.height/2)
        GBackground.scale(to: self.frame.size)
        
        addChild(GBackground)
        
        SoundTrack.sharedInstance.playMusic()
        
        buildTexturesMonster()
        
        
        // player
        
        setupPlayer()
        
        
        // score properties
        
        scoreLabel = SKLabelNode(text: "score: 0")
        scoreLabel.position = CGPoint(x: 100, y: self.frame.size.height - 60)
        
        scoreLabel.fontSize = 60
        scoreLabel.fontColor = .black
        score = 0
        self.addChild(scoreLabel)
        gameTimer = Timer.scheduledTimer(timeInterval: level, target: self, selector: #selector(addItem), userInfo: nil, repeats: true)
        if AI {
        AIturn = Timer.scheduledTimer(timeInterval: 0.25, target: self, selector: #selector(AIBrain), userInfo: nil, repeats: true)
        }
        
        
    }
    public func activateAI(){
        self.AI = true
    }
    func buildTexturesMonster() {
        
        var eatingFrames: [SKTexture] = []
        eatingFrames.append(SKTexture(imageNamed: "monster2.png"))
        eatingFrames.append(SKTexture(imageNamed: "monster3.png"))
        
        self.arrayAnimation = eatingFrames
    }
    
    func animateMonster() {
        
        player.run(SKAction.animate(with: self.arrayAnimation,
                                    timePerFrame: 0.2,
                                    resize: false,
                                    restore: true))
    }
    
    public func setupPlayer(){
        print("PlayerSetUp")
        player = SKSpriteNode(imageNamed: "eatingMonster1.png")
        //player.setScale(0.5)
        let size = CGSize(width: 124.5, height: 148.5)
        
        player.scale(to: size)
        print(player.size)
        player.position = CGPoint(x: self.frame.size.width/2, y: player.size.height/2 + 20)
        player.physicsBody = SKPhysicsBody(circleOfRadius: player.size.width/2)
        player.physicsBody?.categoryBitMask = playerCategory
        player.physicsBody?.collisionBitMask = foodCategory   //com quem vai colidir
        player.physicsBody?.isDynamic = false
        // quando colidir com food vai chamar didBegin(contact:)
        player.physicsBody?.contactTestBitMask = foodCategory
        
        self.addChild(player)
        
        
    }
    
    @objc public func addItem(){
        possibleItem = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: possibleItem) as! [String]
        let widthView = self.frame.size.width / 5
        let widhtPlayer = player.size.width / 2
        let randomItemPosition = GKRandomDistribution(lowestValue: 0, highestValue: 4)
        let pos = CGFloat(randomItemPosition.nextInt()) * widthView
        
        let position = CGFloat(pos + widhtPlayer)
        let item = SKSpriteNode(imageNamed: possibleItem[0])
        
        item.name = possibleItem[0]
        item.scale(to: player.size)
        item.position = CGPoint(x: position, y: self.frame.size.height + item.size.height)
        //food.setScale(0.7)
        item.physicsBody = SKPhysicsBody(rectangleOf: item.size)
        item.physicsBody?.isDynamic = true
        
        item.physicsBody?.categoryBitMask = trashCategory
        item.physicsBody?.contactTestBitMask = playerCategory
        item.physicsBody?.collisionBitMask = 0
        
        
        if possibleItem[0] == "trash.png" {
            item.physicsBody?.categoryBitMask = trashCategory
        }
        else{
            item.physicsBody?.categoryBitMask = foodCategory
        }
        
        
        // add item and move it
        self.addChild(item)
        self.arrayBoladao.append(item)
        
        // food.run(foodRotate)
        
        let animationDuration:TimeInterval = 6.5 - velocity
        
        var actionArray = [SKAction]()
        
        
        actionArray.append(SKAction.move(to: CGPoint(x: position, y: -item.size.height), duration: animationDuration))
        actionArray.append(SKAction.removeFromParent())
        
        item.run(SKAction.sequence(actionArray))
        
    }
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        for touch in touches
        {
            let oldLocation = touch.previousLocation(in: self)
            let location = touch.location(in: self)
            player.position.x += (location.x - oldLocation.x)
        }
        
    }
    public func didBegin(_ contact: SKPhysicsContact) {
        var firstBody:SKPhysicsBody
        var secondBody:SKPhysicsBody
        
        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
            firstBody = contact.bodyA
            secondBody = contact.bodyB
        }else{
            firstBody = contact.bodyB
            secondBody = contact.bodyA
        }
        if(firstBody.categoryBitMask == playerCategory && secondBody.categoryBitMask == foodCategory){
            print(arrayBoladao[0].name ?? "hy")
            animateMonster()
            
            
            
            arrayBoladao.remove(at: 0)
            secondBody.node?.removeFromParent()
            
            
            //player.run()
            
            score += 5
            level -= 0.05
            if(score >= 300){
                self.isPaused = true
                SoundTrack.sharedInstance.stopMusic()
                let newScene = WinScene()
                view?.presentScene(newScene)
            }
            
            
            SoundTrack.sharedInstance.playSound(withName: "bite")
            
            
        }
        else if(firstBody.categoryBitMask == playerCategory && secondBody.categoryBitMask == trashCategory){
            firstBody.node?.removeFromParent()
            
            SoundTrack.sharedInstance.playSound(withName: "Crash")
            self.isPaused = true
            SoundTrack.sharedInstance.stopMusic()
            let newScene = GameOverScene()
            view?.presentScene(newScene)
        }
        
    }
    
    
    
    public func verifyNodePosition(){
        if arrayBoladao[0].position.y <= -player.size.height/2{
            arrayBoladao.remove(at: 0)
        }
        
    }
    
    override public func update(_ currentTime: TimeInterval) {
        if arrayBoladao.count > 0{
            verifyNodePosition()
        }
        
    }
    
    //MARK:
    func AImove(curentPos:Int , direcao:Int){
        let widthView = self.frame.size.width / 5
        let widhtPlayer = player.size.width / 2
        var allPositions: [CGFloat] = []
        for i in 0...4{
            allPositions.append((CGFloat(i) * widthView) + widhtPlayer)
        }
        let movimento = allPositions[curentPos + direcao]
        let moveAction = SKAction.moveTo(x: movimento, duration: 0.16)
        player.run(moveAction)
        
    }
    func playerLane (_ pos : CGFloat) -> Int{
        let widthView = self.frame.size.width / 5
        
        var allPositions: [CGFloat] = []
        for i in 0...4{
            allPositions.append(CGFloat(i) * widthView)
        }
        if ( pos < allPositions[1]){
            return 0
        }
        if ( pos < allPositions[2]){
            return 1
        }
        if ( pos < allPositions[3]){
            return 2
        }
        if ( pos < allPositions[4]){
            return 3
        }
        return 4
        
    }
    @objc func AIBrain(){
        let pLane = playerLane(player.position.x)
        if arrayBoladao.count == 0 {
            return
        }
        
        if(arrayBoladao[0].name == "trash.png"){
            if(player.position.x >= arrayBoladao[0].position.x - 20 && player.position.x <= arrayBoladao[0].position.x + 20) {
                if(pLane < 4){
                    AImove(curentPos: pLane , direcao: 1)
                    print("move , right, trash")
                }
                AImove(curentPos: pLane , direcao: -1)
                print("move , left, trash")
            }
            return
        }
        else{
            if(player.position.x <  (arrayBoladao[0].position.x - 20)){
                AImove(curentPos: pLane, direcao: 1)
                print("move , right, food")
                
            }
            if(player.position.x > (arrayBoladao[0].position.x + 20)){
                AImove(curentPos: pLane, direcao: -1)
                print("move , left, food")
            }
            return
        }
    }
    
    
}

















