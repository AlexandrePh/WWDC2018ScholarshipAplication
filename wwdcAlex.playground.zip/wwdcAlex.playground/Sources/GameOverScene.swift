//
//  GameOverScene.swift
//  1.0_WWDC2018
//
//  Created by alexandre philippi on 21/03/18.
//  Copyright © 2018 Alexandre Philippi. All rights reserved.
//

import SpriteKit
import GameplayKit

public class GameOverScene: SKScene{
    
    private var gameOverLabel:SKLabelNode!
    private var backGround:SKSpriteNode!
    
    override public func didMove(to view: SKView) {
        self.backgroundColor = .black
        //self.anchorPoint = CGPoint.zero
        gameOverLabel = SKLabelNode(text: "GAME OVER")
        
        backGround = SKSpriteNode(imageNamed: "youLoose.png")
        backGround.position = CGPoint(x: self.frame.size.width/2, y: self.frame.size.height/2)
        backGround.scale(to: self.frame.size)
        
        addChild(backGround)
        
        
        
        gameOverLabel.fontSize = 70
        gameOverLabel.fontColor = UIColor.white
        self.addChild(gameOverLabel)
    }
    
}
