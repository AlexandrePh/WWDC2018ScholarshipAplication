

import Foundation
import AVFoundation


private let _SoundTrack = SoundTrack()

open class SoundTrack{
    
    public class var sharedInstance: SoundTrack{
        return _SoundTrack
    }
    
    private var player: AVAudioPlayer?
    private var musicPlayer: AVAudioPlayer?

    public func stopSound(){
        self.player?.stop()
    }
    public func stopMusic(){
        self.musicPlayer?.stop()
    }
    
    public func playSound(withName: String) {
    let url = Bundle.main.url(forResource: withName, withExtension: "mp3")!
        
    do {
        player = try AVAudioPlayer(contentsOf: url)
        guard let player = player else { return }
        
        player.prepareToPlay()
        player.play()
    } catch let error {
        print(error.localizedDescription)
    }
    
    }
    
    public func playMusic() {
        let url = Bundle.main.url(forResource: "Coupe", withExtension: "mp3")!
        do {
            musicPlayer = try AVAudioPlayer(contentsOf: url)
            guard let musicPlayer = musicPlayer else { return }
            
            musicPlayer.prepareToPlay()
            musicPlayer.play()
        } catch let error {
            print(error.localizedDescription)
        }
     musicPlayer?.numberOfLoops = -1
    }
    public func playMusic2() {
        let url = Bundle.main.url(forResource: "GameOver", withExtension: "mp3")!
        do {
            musicPlayer = try AVAudioPlayer(contentsOf: url)
            guard let musicPlayer = musicPlayer else { return }
            
            musicPlayer.prepareToPlay()
            musicPlayer.volume = 0.2
            musicPlayer.play()
        } catch let error {
            print(error.localizedDescription)
        }
        //musicPlayer?.numberOfLoops = -1
    }

}
